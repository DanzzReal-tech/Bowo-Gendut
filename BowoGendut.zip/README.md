# BowoGendut
Plugin server Minecraft 1.16 - 26.3 (Paper/Spigot/Purpur). Tidak jalan di Folia.

## Build
    mvn package   ->   target/BowoGendut.jar  ->  folder plugins

## Perintah
/bg (alias /bowogendut /joget /dance /goyang)  joget, gui, stop, style, song, npc, massal, finale, reload
/mbg   claim | harian | makan | menu | donasi | dapur | gizi | top
/tebak [tebak|kata|math|angka|stop]
/poin  /tukar  /radio  /emot

Semua teks, hadiah, makanan MBG, toko poin, emot diatur di config.yml.
Lagu: songs.yml (note block) atau lagu custom lewat resource pack (custom-sound).
Pertanyaan tebak-tebakan: tebak.yml.
