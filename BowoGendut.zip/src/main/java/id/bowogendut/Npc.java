package id.bowogendut;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.EulerAngle;

/** NPC joget: armor stand dengan kepala skin, badan berputar dan tangan melambai. */
public class Npc {

    public static final String TAG = "bowogendut_npc";

    private final BowoGendut plugin;
    private final Location base;
    private ArmorStand stand;
    private BukkitTask anim, music;
    private int t = 0;

    public Npc(BowoGendut plugin, Location base) {
        this.plugin = plugin;
        this.base = base.clone();
    }

    public Location base() { return base; }

    public void start() {
        spawnStand();
        anim = new BukkitRunnable() {
            @Override
            public void run() { tick(); }
        }.runTaskTimer(plugin, 1L, 2L);

        String song = plugin.getConfig().getString("npc.song", "joget-beat");
        double radius = plugin.getConfig().getDouble("npc.hear-radius", 25);
        music = plugin.songs().play(song, () -> stand != null && stand.isValid() ? stand.getLocation() : base, radius);
    }

    public void stop() {
        if (anim != null) anim.cancel();
        if (music != null) music.cancel();
        if (stand != null) stand.remove();
        stand = null;
    }

    private boolean chunkLoaded() {
        return base.getWorld() != null
                && base.getWorld().isChunkLoaded(base.getBlockX() >> 4, base.getBlockZ() >> 4);
    }

    @SuppressWarnings("deprecation")
    private void spawnStand() {
        if (base.getWorld() == null) return;
        FileConfiguration c = plugin.getConfig();
        ArmorStand st = base.getWorld().spawn(base, ArmorStand.class);
        st.addScoreboardTag(TAG);
        st.setArms(true);
        st.setBasePlate(false);
        st.setGravity(false);
        st.setInvulnerable(true);
        st.setPersistent(false);
        st.setCustomName(plugin.color(c.getString("npc.name", "&c&lSi Joget")));
        st.setCustomNameVisible(true);

        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta sm = (SkullMeta) head.getItemMeta();
        if (sm != null) {
            sm.setOwner(c.getString("npc.skin-owner", "Notch"));
            head.setItemMeta(sm);
        }
        EntityEquipment eq = st.getEquipment();
        if (eq != null) {
            eq.setHelmet(head);
            eq.setChestplate(leather(Material.LEATHER_CHESTPLATE, c.getString("npc.shirt-color", "200,30,30")));
            eq.setLeggings(leather(Material.LEATHER_LEGGINGS, c.getString("npc.pants-color", "30,30,30")));
            eq.setBoots(leather(Material.LEATHER_BOOTS, "10,10,10"));
        }
        stand = st;
    }

    private static ItemStack leather(Material m, String rgb) {
        ItemStack it = new ItemStack(m);
        LeatherArmorMeta lm = (LeatherArmorMeta) it.getItemMeta();
        if (lm != null) {
            int r = 200, g = 30, b = 30;
            try {
                String[] p = rgb.split(",");
                r = Integer.parseInt(p[0].trim());
                g = Integer.parseInt(p[1].trim());
                b = Integer.parseInt(p[2].trim());
            } catch (Exception ignored) { }
            lm.setColor(Color.fromRGB(clamp(r), clamp(g), clamp(b)));
            it.setItemMeta(lm);
        }
        return it;
    }

    private static int clamp(int v) { return Math.max(0, Math.min(255, v)); }

    private void tick() {
        if (stand == null || !stand.isValid()) {
            // chunk sempat unload -> spawn ulang kalau chunk sudah loaded
            if (chunkLoaded()) spawnStand();
            return;
        }
        t++;
        double s = Math.sin(t * 0.6);
        double up = Math.toRadians(-165);
        stand.setHeadPose(new EulerAngle(0, 0, s * 0.3));
        stand.setRightArmPose(new EulerAngle(up + s * 0.5, 0, s * 0.5));
        stand.setLeftArmPose(new EulerAngle(up - s * 0.5, 0, -s * 0.5));
        stand.setRightLegPose(new EulerAngle(s * 0.7, 0, 0));
        stand.setLeftLegPose(new EulerAngle(-s * 0.7, 0, 0));

        Location l = base.clone();
        l.setYaw(base.getYaw() + t * 12f);
        l.setY(base.getY() + Math.abs(s) * 0.15);
        stand.teleport(l);

        if (t % 8 == 0 && plugin.getConfig().getBoolean("dance.particles", true))
            plugin.noteParticle(stand.getLocation().add(0, 2.4, 0));
    }
}
