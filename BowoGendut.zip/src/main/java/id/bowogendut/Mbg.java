package id.bowogendut;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Fitur MBG: paket makan, harian, jam makan, skor gizi, dapur umum. */
public class Mbg {

    private final BowoGendut pl;
    private final Map<String, Set<Material>> groups = new LinkedHashMap<String, Set<Material>>();
    private final Map<UUID, Set<String>> eaten = new HashMap<UUID, Set<String>>();

    private boolean windowOpen;
    private final Set<UUID> windowClaimed = new HashSet<UUID>();
    private BossBar bar;
    private BukkitTask windowTask, scheduler;

    public Mbg(BowoGendut pl) {
        this.pl = pl;
        reload();
    }

    public void reload() {
        groups.clear();
        ConfigurationSection sec = pl.getConfig().getConfigurationSection("mbg.gizi-groups");
        if (sec != null) {
            for (String g : sec.getKeys(false)) {
                Set<Material> set = new HashSet<Material>();
                for (String name : sec.getStringList(g)) {
                    Material m = Material.matchMaterial(name);
                    if (m != null) set.add(m);   // bahan yang belum ada di versi ini dilewati
                }
                groups.put(g, set);
            }
        }
        if (scheduler != null) scheduler.cancel();
        if (pl.getConfig().getBoolean("mbg.jam-makan.enabled", true)) {
            long period = Math.max(1, pl.getConfig().getInt("mbg.jam-makan.interval-minutes", 30)) * 60L * 20L;
            scheduler = new BukkitRunnable() {
                @Override
                public void run() {
                    if (!Bukkit.getOnlinePlayers().isEmpty()) startWindow();
                }
            }.runTaskTimer(pl, period, period);
        }
    }

    public void shutdown() {
        if (scheduler != null) scheduler.cancel();
        closeWindow();
    }

    // ---------------------------------------------------------------- paket makan

    public void giveRation(Player p) {
        for (String s : pl.getConfig().getStringList("mbg.paket")) {
            try {
                String[] a = s.split(":");
                Material m = Material.matchMaterial(a[0]);
                if (m == null) continue;
                int amt = a.length > 1 ? Integer.parseInt(a[1].trim()) : 1;
                for (ItemStack left : p.getInventory().addItem(new ItemStack(m, amt)).values())
                    p.getWorld().dropItemNaturally(p.getLocation(), left);
            } catch (Exception ignored) { }
        }
    }

    public void claim(Player p) {
        long now = System.currentTimeMillis();
        long cd = pl.getConfig().getLong("mbg.cooldown-seconds", 1800) * 1000L;
        long last = pl.data().getLong(p.getUniqueId(), "lastClaim", 0);
        if (now - last < cd) {
            long sisa = (cd - (now - last)) / 1000;
            pl.msg(p, "&cMasih antre dapur. Tunggu &e" + sisa / 60 + "m " + sisa % 60 + "s&c lagi.");
            return;
        }
        pl.data().set(p.getUniqueId(), "lastClaim", now);
        giveRation(p);
        pl.msg(p, "&aPaket MBG diterima! Selamat makan, jaga gizi seimbang.");
    }

    public void daily(Player p) {
        UUID id = p.getUniqueId();
        long today = LocalDate.now().toEpochDay();
        long last = pl.data().getLong(id, "lastDaily", -10);
        if (last == today) { pl.msg(p, "&cMBG harian hari ini sudah diambil. Besok lagi ya!"); return; }
        int streak = (last == today - 1) ? pl.data().getInt(id, "streak") + 1 : 1;
        pl.data().set(id, "streak", streak);
        pl.data().set(id, "lastDaily", today);
        int pts = pl.getConfig().getInt("mbg.harian-poin", 10) * Math.min(streak, 7);
        pl.data().add(id, "points", pts);
        pl.msg(p, "&aMBG harian! Streak &e" + streak + " hari&a, +&e" + pts + " poin&a.");
    }

    public String menuToday() {
        DayOfWeek d = LocalDate.now().getDayOfWeek();
        return pl.getConfig().getString("mbg.menu-harian." + d.name(), "Paket MBG standar");
    }

    // ---------------------------------------------------------------- jam makan

    public void startWindow() {
        if (windowOpen) return;
        windowOpen = true;
        windowClaimed.clear();
        final int dur = Math.max(10, pl.getConfig().getInt("mbg.jam-makan.durasi-detik", 60));
        bar = Bukkit.createBossBar(pl.color("&a&lJAM MAKAN MBG! &f/mbg makan"), BarColor.GREEN, BarStyle.SOLID);
        for (Player p : Bukkit.getOnlinePlayers()) bar.addPlayer(p);
        Bukkit.broadcastMessage(pl.color(pl.getConfig().getString("prefix", "") + "&a&lJam makan MBG dimulai! &fKetik &e/mbg makan &funtuk ambil jatah (" + dur + " detik)."));
        windowTask = new BukkitRunnable() {
            int left = dur;

            @Override
            public void run() {
                left--;
                if (left <= 0) { closeWindow(); return; }
                if (bar != null) bar.setProgress(Math.max(0.0, Math.min(1.0, left / (double) dur)));
            }
        }.runTaskTimer(pl, 20L, 20L);
    }

    public void closeWindow() {
        windowOpen = false;
        if (windowTask != null) windowTask.cancel();
        if (bar != null) { bar.removeAll(); bar = null; }
    }

    public void joinBar(Player p) {
        if (bar != null) bar.addPlayer(p);
    }

    public void windowClaim(Player p) {
        if (!windowOpen) { pl.msg(p, "&cBelum jam makan. Tunggu pengumuman atau pakai &e/mbg claim&c."); return; }
        if (!windowClaimed.add(p.getUniqueId())) { pl.msg(p, "&cJatah jam makan ini sudah kamu ambil."); return; }
        giveRation(p);
        pl.msg(p, "&aJatah jam makan diterima. Selamat makan!");
    }

    // ---------------------------------------------------------------- gizi

    public void onEat(Player p, Material m) {
        String group = null;
        for (Map.Entry<String, Set<Material>> e : groups.entrySet())
            if (e.getValue().contains(m)) { group = e.getKey(); break; }
        if (group == null) return;
        UUID id = p.getUniqueId();
        pl.data().add(id, "gizi", 1);
        Set<String> set = eaten.get(id);
        if (set == null) { set = new HashSet<String>(); eaten.put(id, set); }
        set.add(group);
        if (set.size() >= groups.size()) {
            set.clear();
            pl.data().add(id, "gizi", 10);
            pl.data().add(id, "points", 5);
            buff(p);
            pl.msg(p, "&a&lGizi seimbang! &fSemua kelompok makanan terpenuhi: +10 gizi, +5 poin, dan buff sementara.");
        } else {
            pl.msg(p, "&7Kelompok &e" + group + "&7 tercatat (" + set.size() + "/" + groups.size() + ").");
        }
    }

    private void buff(Player p) {
        int ticks = pl.getConfig().getInt("mbg.buff-seconds", 60) * 20;
        String[] names = {"REGENERATION", "SATURATION", "SPEED"};
        for (String n : names) {
            @SuppressWarnings("deprecation")
            PotionEffectType t = PotionEffectType.getByName(n);
            if (t != null) p.addPotionEffect(new PotionEffect(t, ticks, 0));
        }
    }

    public void giziStatus(Player p) {
        Set<String> set = eaten.get(p.getUniqueId());
        StringBuilder sb = new StringBuilder();
        for (String g : groups.keySet()) {
            boolean ok = set != null && set.contains(g);
            sb.append(ok ? "&a" : "&7").append(g).append(" ");
        }
        pl.msg(p, "Skor gizi: &e" + pl.data().getInt(p.getUniqueId(), "gizi") + "&f | Kelompok siklus ini: " + sb.toString());
    }

    // ---------------------------------------------------------------- dapur umum

    public void donate(Player p) {
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand == null || hand.getType() == Material.AIR) { pl.msg(p, "&cPegang makanan di tangan dulu."); return; }
        boolean valid = false;
        for (Set<Material> s : groups.values()) if (s.contains(hand.getType())) valid = true;
        if (!valid) { pl.msg(p, "&cItem ini bukan bahan MBG."); return; }
        int amt = hand.getAmount();
        p.getInventory().setItemInMainHand(null);
        int target = Math.max(1, pl.getConfig().getInt("mbg.dapur-target", 300));
        int prog = pl.data().global("dapur") + amt;
        pl.data().add(p.getUniqueId(), "points", Math.max(1, amt / 2));
        pl.data().add(p.getUniqueId(), "gizi", 1);
        if (prog >= target) {
            pl.data().setGlobal("dapur", prog - target);
            int hadiah = pl.getConfig().getInt("mbg.dapur-hadiah-poin", 25);
            Bukkit.broadcastMessage(pl.color(pl.getConfig().getString("prefix", "") + "&a&lDapur umum penuh! &f" + p.getName() + " menuntaskan target. Semua pemain online dapat +" + hadiah + " poin dan buff."));
            for (Player o : Bukkit.getOnlinePlayers()) {
                pl.data().add(o.getUniqueId(), "points", hadiah);
                buff(o);
            }
        } else {
            pl.data().setGlobal("dapur", prog);
            pl.msg(p, "Terima kasih! Dapur umum: " + bar(prog, target));
        }
    }

    public void dapurStatus(Player p) {
        int target = Math.max(1, pl.getConfig().getInt("mbg.dapur-target", 300));
        pl.msg(p, "Dapur umum: " + bar(pl.data().global("dapur"), target) + "  &7(/mbg donasi)");
    }

    private String bar(int v, int max) {
        int filled = (int) Math.round(10.0 * Math.min(v, max) / max);
        StringBuilder sb = new StringBuilder("&a");
        for (int i = 0; i < 10; i++) { if (i == filled) sb.append("&7"); sb.append("|"); }
        return sb.append(" &f").append(v).append("/").append(max).toString();
    }

    public void top(Player p) {
        pl.msg(p, "&6Peringkat gizi:");
        List<Map.Entry<String, Integer>> t = pl.data().top("gizi", 5);
        if (t.isEmpty()) p.sendMessage(pl.color("&7Belum ada data."));
        int i = 1;
        for (Map.Entry<String, Integer> e : t) p.sendMessage(pl.color("&e" + (i++) + ". &f" + e.getKey() + " &7- &a" + e.getValue()));
    }
}
