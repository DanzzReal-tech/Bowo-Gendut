package id.bowogendut;

import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/** Pemutar lagu berbasis note block (pakai nama sound string -> aman di semua versi). */
public class SongPlayer {

    public static class Song {
        public String id, title, drums = "";
        public int tempo = 5;
        public String[] melody = new String[0], bass = new String[0];
    }

    public static final String CUSTOM = "custom";

    private final BowoGendut plugin;
    private final Map<String, Song> songs = new LinkedHashMap<String, Song>();

    public SongPlayer(BowoGendut plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        songs.clear();
        File f = new File(plugin.getDataFolder(), "songs.yml");
        if (!f.exists()) plugin.saveResource("songs.yml", false);
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        ConfigurationSection sec = y.getConfigurationSection("songs");
        if (sec == null) return;
        for (String id : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(id);
            if (s == null) continue;
            Song so = new Song();
            so.id = id;
            so.title = s.getString("title", id);
            so.tempo = Math.max(1, s.getInt("tempo", 5));
            so.melody = split(s.getString("melody", ""));
            so.bass = split(s.getString("bass", ""));
            so.drums = s.getString("drums", "");
            songs.put(id, so);
        }
    }

    private static String[] split(String s) {
        s = s.trim();
        return s.isEmpty() ? new String[0] : s.split("\\s+");
    }

    public Map<String, Song> all() { return songs; }

    public Song get(String id) { return songs.get(id); }

    /** Daftar id lagu + "custom" di akhir. */
    public List<String> ids() {
        List<String> l = new ArrayList<String>(songs.keySet());
        l.add(CUSTOM);
        return l;
    }

    public String title(String id) {
        if (CUSTOM.equals(id)) return "Lagu Custom (resource pack)";
        Song s = songs.get(id);
        return s == null ? id : s.title;
    }

    /** Putar lagu berulang. where = posisi sumber suara (null -> berhenti sendiri). */
    public BukkitTask play(String id, final Supplier<Location> where, final double radius) {
        if (CUSTOM.equals(id)) return playCustom(where, radius);
        final Song song = songs.get(id);
        if (song == null) return null;
        return new BukkitRunnable() {
            int step = 0;

            @Override
            public void run() {
                Location at = where.get();
                if (at == null || at.getWorld() == null) { cancel(); return; }
                List<Player> ears = nearby(at, radius);
                if (!ears.isEmpty()) {
                    if (song.melody.length > 0)
                        note(ears, at, "block.note_block.harp", song.melody[step % song.melody.length], 2f);
                    if (song.bass.length > 0)
                        note(ears, at, "block.note_block.bass", song.bass[step % song.bass.length], 2f);
                    if (!song.drums.isEmpty()) {
                        char c = song.drums.charAt(step % song.drums.length());
                        if (c == 'x') all(ears, at, "block.note_block.basedrum", 1f);
                        else if (c == 's') all(ears, at, "block.note_block.snare", 1f);
                        else if (c == 'h') all(ears, at, "block.note_block.hat", 1f);
                    }
                }
                step++;
            }
        }.runTaskTimer(plugin, 0L, song.tempo);
    }

    /** Lagu dari resource pack, diulang tiap loop-seconds. */
    private BukkitTask playCustom(final Supplier<Location> where, final double radius) {
        final String key = plugin.getConfig().getString("custom-sound.key", "joget:lagu.utama");
        final float vol = (float) plugin.getConfig().getDouble("custom-sound.volume", 1.0);
        final float pitch = (float) plugin.getConfig().getDouble("custom-sound.pitch", 1.0);
        long loop = Math.max(1, plugin.getConfig().getInt("custom-sound.loop-seconds", 60)) * 20L;
        return new BukkitRunnable() {
            @Override
            public void run() {
                Location at = where.get();
                if (at == null || at.getWorld() == null) { cancel(); return; }
                for (Player p : nearby(at, radius)) p.playSound(at, key, vol, pitch);
            }
        }.runTaskTimer(plugin, 0L, loop);
    }

    private static List<Player> nearby(Location at, double radius) {
        List<Player> out = new ArrayList<Player>();
        double r2 = radius * radius;
        for (Player p : at.getWorld().getPlayers())
            if (p.getLocation().distanceSquared(at) <= r2) out.add(p);
        return out;
    }

    private static void note(List<Player> ears, Location at, String sound, String token, float vol) {
        if (token.equals("-")) return;
        int n;
        try { n = Integer.parseInt(token); } catch (NumberFormatException e) { return; }
        n = Math.max(0, Math.min(24, n));
        all(ears, at, sound, vol, (float) Math.pow(2.0, (n - 12) / 12.0));
    }

    private static void all(List<Player> ears, Location at, String sound, float vol) {
        all(ears, at, sound, vol, 1f);
    }

    private static void all(List<Player> ears, Location at, String sound, float vol, float pitch) {
        for (Player p : ears) p.playSound(at, sound, vol, pitch);
    }
}
