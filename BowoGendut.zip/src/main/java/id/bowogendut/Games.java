package id.bowogendut;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

/** Permainan chat: tebak-tebakan, susun kata, matematika cepat, tebak angka. */
public class Games {

    public enum Type { TEBAK, KATA, MATEMATIKA, ANGKA }

    private static final String[] WORDS = {
            "creeper", "obsidian", "diamond", "zombie", "skeleton", "enderman", "redstone",
            "villager", "pickaxe", "netherite", "spawner", "beacon", "elytra", "trident"
    };

    private final BowoGendut pl;
    private final Random rnd = new Random();
    private final List<String[]> riddles = new ArrayList<String[]>();

    private Type active;
    private final Set<String> answers = new HashSet<String>();
    private int secret;
    private String revealAnswer = "";
    private BukkitTask timeout, auto;
    private long lastStart;

    public Games(BowoGendut pl) {
        this.pl = pl;
        reload();
    }

    public void reload() {
        riddles.clear();
        File f = new File(pl.getDataFolder(), "tebak.yml");
        if (!f.exists()) pl.saveResource("tebak.yml", false);
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        for (String line : y.getStringList("tebak")) {
            String[] p = line.split("\\|", 2);
            if (p.length == 2) riddles.add(p);
        }
        if (auto != null) auto.cancel();
        if (pl.getConfig().getBoolean("games.auto-enabled", true)) {
            long period = Math.max(1, pl.getConfig().getInt("games.auto-minutes", 10)) * 60L * 20L;
            auto = new BukkitRunnable() {
                @Override
                public void run() {
                    if (active == null && !Bukkit.getOnlinePlayers().isEmpty()) {
                        Type[] ts = Type.values();
                        start(null, ts[rnd.nextInt(ts.length)]);
                    }
                }
            }.runTaskTimer(pl, period, period);
        }
    }

    public void shutdown() {
        if (auto != null) auto.cancel();
        end();
    }

    public boolean isActive() { return active != null; }

    private void announce(String text) {
        Bukkit.broadcastMessage(pl.color(pl.getConfig().getString("prefix", "") + text));
    }

    /** by == null berarti dimulai otomatis. */
    public boolean start(CommandSender by, Type t) {
        if (active != null) { if (by != null) pl.msg(by, "&cMasih ada permainan berjalan."); return false; }
        if (by != null && !by.hasPermission("bowogendut.admin")) {
            long cd = pl.getConfig().getLong("games.start-cooldown-seconds", 60) * 1000L;
            long left = cd - (System.currentTimeMillis() - lastStart);
            if (left > 0) { pl.msg(by, "&cTunggu " + (left / 1000 + 1) + " detik lagi."); return false; }
        }
        answers.clear();
        int seconds = pl.getConfig().getInt("games.timeout-seconds", 30);
        switch (t) {
            case TEBAK: {
                if (riddles.isEmpty()) return false;
                String[] r = riddles.get(rnd.nextInt(riddles.size()));
                for (String a : r[1].split(",")) answers.add(norm(a));
                revealAnswer = r[1].split(",")[0].trim();
                announce("&b&lTEBAK-TEBAKAN! &f" + r[0] + " &7(" + seconds + " detik, ketik jawaban di chat)");
                break;
            }
            case KATA: {
                String w = WORDS[rnd.nextInt(WORDS.length)];
                answers.add(w);
                revealAnswer = w;
                announce("&b&lSUSUN KATA! &fHuruf acak: &e" + scramble(w) + " &7(" + seconds + " detik)");
                break;
            }
            case MATEMATIKA: {
                int a = 2 + rnd.nextInt(18), b = 2 + rnd.nextInt(12), op = rnd.nextInt(3);
                int res = op == 0 ? a + b : op == 1 ? a * b : a - b;
                String sym = op == 0 ? "+" : op == 1 ? "x" : "-";
                answers.add(String.valueOf(res));
                revealAnswer = String.valueOf(res);
                announce("&b&lMATEMATIKA CEPAT! &fBerapa &e" + a + " " + sym + " " + b + "&f? &7(" + seconds + " detik)");
                break;
            }
            default: {
                secret = 1 + rnd.nextInt(100);
                revealAnswer = String.valueOf(secret);
                seconds = pl.getConfig().getInt("games.angka-timeout-seconds", 120);
                announce("&b&lTEBAK ANGKA! &fAku memikirkan angka &e1-100&f. Ketik tebakanmu di chat! &7(" + seconds + " detik)");
                break;
            }
        }
        active = t;
        lastStart = System.currentTimeMillis();
        timeout = new BukkitRunnable() {
            @Override
            public void run() {
                announce("&cWaktu habis! Jawabannya: &e" + revealAnswer);
                end();
            }
        }.runTaskLater(pl, seconds * 20L);
        return true;
    }

    public void stop(CommandSender by) {
        if (active == null) { pl.msg(by, "&cTidak ada permainan."); return; }
        announce("&7Permainan dihentikan. Jawabannya: &e" + revealAnswer);
        end();
    }

    private void end() {
        if (timeout != null) timeout.cancel();
        timeout = null;
        active = null;
        answers.clear();
    }

    /** Dipanggil di main thread untuk setiap pesan chat. */
    public void handleChat(Player p, String msg) {
        if (active == null) return;
        if (active == Type.ANGKA) {
            int n;
            try { n = Integer.parseInt(msg.trim()); } catch (NumberFormatException e) { return; }
            if (n == secret) win(p);
            else pl.msg(p, n < secret ? "&eTerlalu kecil!" : "&eTerlalu besar!");
            return;
        }
        if (answers.contains(norm(msg))) win(p);
    }

    private void win(Player p) {
        String ans = revealAnswer;
        end();
        int pts = pl.getConfig().getInt("games.reward-points", 10);
        pl.data().add(p.getUniqueId(), "points", pts);
        announce("&a&l" + p.getName() + " &abenar! Jawaban: &e" + ans + " &7(+" + pts + " poin)");
        for (String cmd : pl.getConfig().getStringList("games.reward-commands"))
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", p.getName()));
    }

    private static String norm(String s) {
        return s.toLowerCase(Locale.ROOT).trim().replaceAll("[^a-z0-9 ]", "");
    }

    private String scramble(String w) {
        List<String> chars = new ArrayList<String>(Arrays.asList(w.split("")));
        String out = w;
        for (int i = 0; i < 10 && out.equals(w); i++) {
            Collections.shuffle(chars, rnd);
            StringBuilder sb = new StringBuilder();
            for (String c : chars) sb.append(c);
            out = sb.toString();
        }
        return out.toUpperCase(Locale.ROOT);
    }
}
