package id.bowogendut;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class BowoGendut extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    private static class GuiHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() { return null; }
    }

    private static class Session {
        BukkitTask anim, music, stopper;
    }

    private static final List<String> STYLES = Arrays.asList("spin", "hop", "disco");

    private SongPlayer songs;
    private Data data;
    private Mbg mbg;
    private Games games;
    private Particle noteParticle;
    private BukkitTask saver;

    private final Map<UUID, Session> sessions = new HashMap<UUID, Session>();
    private final Map<UUID, BukkitTask> radios = new HashMap<UUID, BukkitTask>();
    private final Map<UUID, String> chosen = new HashMap<UUID, String>();
    private final Map<UUID, String> styles = new HashMap<UUID, String>();
    private final Map<String, String> emots = new LinkedHashMap<String, String>();
    private final List<Npc> npcs = new ArrayList<Npc>();

    public SongPlayer songs() { return songs; }

    public Data data() { return data; }

    public String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }

    public void msg(CommandSender to, String text) {
        to.sendMessage(color(getConfig().getString("prefix", "&6[BowoGendut] &f") + text));
    }

    // ================================================================ lifecycle

    @Override
    public void onEnable() {
        saveDefaultConfig();
        songs = new SongPlayer(this);
        data = new Data(this);
        mbg = new Mbg(this);
        games = new Games(this);
        loadEmots();
        try {
            // lewat refleksi: aman walau Particle berubah dari enum ke interface di versi baru
            noteParticle = (Particle) Particle.class.getField("NOTE").get(null);
        } catch (Throwable t) {
            noteParticle = null;
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        for (String name : new String[]{"bowogendut", "mbg", "tebak", "poin", "tukar", "radio", "emot"}) {
            if (getCommand(name) != null) {
                getCommand(name).setExecutor(this);
                getCommand(name).setTabCompleter(this);
            }
        }
        saver = new BukkitRunnable() {
            @Override
            public void run() { data.save(); }
        }.runTaskTimer(this, 6000L, 6000L);
        Bukkit.getScheduler().runTask(this, new Runnable() {
            @Override
            public void run() { loadNpcs(); }
        });
    }

    @Override
    public void onDisable() {
        if (saver != null) saver.cancel();
        for (UUID id : new ArrayList<UUID>(sessions.keySet())) stopSession(id);
        for (BukkitTask t : radios.values()) t.cancel();
        radios.clear();
        for (Npc n : npcs) n.stop();
        npcs.clear();
        if (mbg != null) mbg.shutdown();
        if (games != null) games.shutdown();
        if (data != null) data.save();
    }

    private void loadEmots() {
        emots.clear();
        ConfigurationSection s = getConfig().getConfigurationSection("emot");
        if (s != null) for (String k : s.getKeys(false)) emots.put(k.toLowerCase(Locale.ROOT), s.getString(k, ""));
    }

    // ================================================================ NPC storage

    private File npcFile() { return new File(getDataFolder(), "npcs.yml"); }

    private void saveNpcs() {
        YamlConfiguration y = new YamlConfiguration();
        List<String> out = new ArrayList<String>();
        for (Npc n : npcs) {
            Location l = n.base();
            out.add(l.getWorld().getName() + ";" + l.getX() + ";" + l.getY() + ";" + l.getZ() + ";" + l.getYaw());
        }
        y.set("npcs", out);
        try { y.save(npcFile()); } catch (IOException e) { getLogger().warning("Gagal simpan npcs.yml: " + e.getMessage()); }
    }

    private void loadNpcs() {
        if (!npcFile().exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(npcFile());
        for (String line : y.getStringList("npcs")) {
            try {
                String[] p = line.split(";");
                if (Bukkit.getWorld(p[0]) == null) continue;
                Location l = new Location(Bukkit.getWorld(p[0]), Double.parseDouble(p[1]), Double.parseDouble(p[2]),
                        Double.parseDouble(p[3]), Float.parseFloat(p[4]), 0f);
                Npc n = new Npc(this, l);
                n.start();
                npcs.add(n);
            } catch (Exception e) {
                getLogger().warning("Baris NPC rusak: " + line);
            }
        }
    }

    private void spawnNpc(Player p) {
        Npc n = new Npc(this, p.getLocation());
        n.start();
        npcs.add(n);
        saveNpcs();
        msg(p, "NPC joget di-spawn.");
    }

    private void removeNearest(Player p) {
        Npc best = null;
        double bd = 36;
        for (Npc n : npcs) {
            if (n.base().getWorld() != p.getWorld()) continue;
            double d = n.base().distanceSquared(p.getLocation());
            if (d < bd) { bd = d; best = n; }
        }
        if (best == null) { msg(p, "Tidak ada NPC dalam radius 6 blok."); return; }
        best.stop();
        npcs.remove(best);
        saveNpcs();
        msg(p, "NPC dihapus.");
    }

    // ================================================================ dance

    public void noteParticle(Location l) {
        if (noteParticle == null || l.getWorld() == null) return;
        l.getWorld().spawnParticle(noteParticle, l, 3, 0.6, 0.4, 0.6, 1.0);
    }

    private String songOf(UUID id) {
        String s = chosen.get(id);
        return s != null ? s : getConfig().getString("npc.song", "joget-beat");
    }

    private String styleOf(UUID id) {
        String s = styles.get(id);
        return s != null ? s : getConfig().getString("dance.default-style", "spin");
    }

    private void toggle(Player p) {
        if (sessions.containsKey(p.getUniqueId())) {
            stopSession(p.getUniqueId());
            msg(p, "Joget berhenti.");
        } else {
            startDance(p, getConfig().getInt("dance.duration-seconds", 60));
            msg(p, "Joget dimulai! Sneak (Shift) atau /bg untuk berhenti.");
        }
    }

    private void startDance(final Player p, int durationSeconds) {
        stopSession(p.getUniqueId());
        final String style = styleOf(p.getUniqueId());
        final boolean parts = getConfig().getBoolean("dance.particles", true);
        final Session ses = new Session();

        ses.anim = new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (!p.isOnline()) { stopSession(p.getUniqueId()); return; }
                t++;
                if (style.equals("hop")) {
                    if (t % 5 == 0) p.setVelocity(new Vector(0, 0.42, 0));
                } else {
                    Location l = p.getLocation();
                    l.setYaw(l.getYaw() + (style.equals("disco") ? 45f : 25f));
                    p.teleport(l);
                }
                if ((t / 2) % 2 == 0) p.swingMainHand(); else p.swingOffHand();
                if (parts && t % (style.equals("disco") ? 2 : 5) == 0) noteParticle(p.getLocation().add(0, 2.2, 0));
            }
        }.runTaskTimer(this, 0L, 2L);

        ses.music = songs.play(songOf(p.getUniqueId()), () -> p.isOnline() ? p.getLocation() : null, 20);

        if (durationSeconds > 0) {
            ses.stopper = new BukkitRunnable() {
                @Override
                public void run() {
                    stopSession(p.getUniqueId());
                    msg(p, "Joget selesai.");
                    if (getConfig().getBoolean("dance.finale-fireworks", true)) finale(p);
                }
            }.runTaskLater(this, durationSeconds * 20L);
        }
        sessions.put(p.getUniqueId(), ses);
    }

    private void stopSession(UUID id) {
        Session s = sessions.remove(id);
        if (s == null) return;
        if (s.anim != null) s.anim.cancel();
        if (s.music != null) s.music.cancel();
        if (s.stopper != null) s.stopper.cancel();
        Player p = Bukkit.getPlayer(id);
        if (p != null) {
            try { p.stopSound(getConfig().getString("custom-sound.key", "bowogendut:lagu.utama")); } catch (Throwable ignored) { }
        }
    }

    private void finale(Player p) {
        final Firework fw = p.getWorld().spawn(p.getLocation().add(0, 1, 0), Firework.class);
        FireworkMeta m = fw.getFireworkMeta();
        m.addEffect(FireworkEffect.builder().with(FireworkEffect.Type.BALL_LARGE)
                .withColor(Color.RED, Color.WHITE).withFade(Color.YELLOW).flicker(true).build());
        m.setPower(0);
        fw.setFireworkMeta(m);
        Bukkit.getScheduler().runTaskLater(this, new Runnable() {
            @Override
            public void run() { if (fw.isValid()) fw.detonate(); }
        }, 2L);
    }

    private void setSong(Player p, String id) {
        chosen.put(p.getUniqueId(), id);
        if (sessions.containsKey(p.getUniqueId())) startDance(p, getConfig().getInt("dance.duration-seconds", 60));
        if (radios.containsKey(p.getUniqueId())) radioOn(p);
        msg(p, "Lagu: &e" + songs.title(id));
    }

    private void setStyle(Player p, String style) {
        styles.put(p.getUniqueId(), style);
        if (sessions.containsKey(p.getUniqueId())) startDance(p, getConfig().getInt("dance.duration-seconds", 60));
        msg(p, "Gaya joget: &e" + style);
    }

    // ================================================================ radio

    private void radioOn(final Player p) {
        radioOff(p);
        BukkitTask t = songs.play(songOf(p.getUniqueId()), () -> p.isOnline() ? p.getLocation() : null, 4);
        if (t != null) radios.put(p.getUniqueId(), t);
    }

    private void radioOff(Player p) {
        BukkitTask t = radios.remove(p.getUniqueId());
        if (t != null) t.cancel();
    }

    // ================================================================ GUI

    private ItemStack item(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta im = it.getItemMeta();
        if (im != null) {
            im.setDisplayName(color(name));
            List<String> l = new ArrayList<String>();
            for (String s : lore) l.add(color(s));
            im.setLore(l);
            it.setItemMeta(im);
        }
        return it;
    }

    private void openGui(Player p) {
        Inventory inv = Bukkit.createInventory(new GuiHolder(), 36, color("&6&lBowoGendut"));
        ItemStack filler = item(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 36; i++) inv.setItem(i, filler);
        UUID id = p.getUniqueId();
        boolean on = sessions.containsKey(id);
        inv.setItem(10, item(Material.LEATHER_BOOTS, on ? "&aJoget: ON" : "&eMulai Joget", "&7Klik untuk " + (on ? "berhenti" : "mulai")));
        inv.setItem(11, item(Material.NOTE_BLOCK, "&dGaya: &f" + styleOf(id), "&7Klik ganti gaya (spin/hop/disco)"));
        inv.setItem(12, item(Material.JUKEBOX, "&bLagu: &f" + songs.title(songOf(id)), "&7Klik ganti lagu"));
        inv.setItem(13, item(Material.BEACON, "&6Joget Massal", "&7Semua pemain online (admin)"));
        inv.setItem(14, item(Material.BARRIER, "&cStop", "&7Hentikan joget"));
        if (p.hasPermission("bowogendut.npc")) inv.setItem(16, item(Material.ARMOR_STAND, "&dSpawn NPC Joget", "&7Spawn NPC di posisimu"));
        inv.setItem(19, item(Material.BREAD, "&aKlaim Paket MBG", "&7Makan gratis (ada cooldown)"));
        inv.setItem(20, item(Material.CLOCK, "&aMBG Harian", "&7Poin + streak harian"));
        inv.setItem(21, item(Material.BOOK, "&eMenu MBG Hari Ini", "&f" + mbg.menuToday()));
        inv.setItem(22, item(Material.CAULDRON, "&6Dapur Umum", "&7Lihat progres / donasi dengan /mbg donasi"));
        inv.setItem(23, item(Material.PAPER, "&bMulai Tebak-tebakan", "&7Acak: tebak/kata/math/angka"));
        inv.setItem(24, item(Material.GOLD_INGOT, "&6Poin: &f" + data.getInt(id, "points"), "&7Klik lihat peringkat"));
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof GuiHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player)) return;
        Player p = (Player) e.getWhoClicked();
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        UUID id = p.getUniqueId();
        switch (e.getSlot()) {
            case 10: toggle(p); openGui(p); break;
            case 11: {
                int i = STYLES.indexOf(styleOf(id));
                setStyle(p, STYLES.get((i + 1) % STYLES.size()));
                openGui(p);
                break;
            }
            case 12: {
                List<String> ids = songs.ids();
                int i = ids.indexOf(songOf(id));
                setSong(p, ids.get((i + 1) % ids.size()));
                openGui(p);
                break;
            }
            case 13: if (p.hasPermission("bowogendut.admin")) massal(p); break;
            case 14: stopSession(id); openGui(p); break;
            case 16: if (p.hasPermission("bowogendut.npc")) { spawnNpc(p); p.closeInventory(); } break;
            case 19: mbg.claim(p); break;
            case 20: mbg.daily(p); openGui(p); break;
            case 22: mbg.dapurStatus(p); break;
            case 23: games.start(p, Games.Type.values()[new java.util.Random().nextInt(Games.Type.values().length)]); p.closeInventory(); break;
            case 24: showTop(p); break;
            default:
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof GuiHolder) e.setCancelled(true);
    }

    // ================================================================ events

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        final Player p = e.getPlayer();
        data.name(p.getUniqueId(), p.getName());
        mbg.joinBar(p);
        if (getConfig().getBoolean("welcome.enabled", true)) {
            Bukkit.getScheduler().runTaskLater(this, new Runnable() {
                @Override
                public void run() {
                    if (!p.isOnline()) return;
                    for (String line : getConfig().getStringList("welcome.lines"))
                        p.sendMessage(color(line.replace("%player%", p.getName())));
                }
            }, 40L);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        stopSession(id);
        radioOff(e.getPlayer());
        chosen.remove(id);
        styles.remove(id);
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        if (e.isSneaking() && sessions.containsKey(e.getPlayer().getUniqueId())) {
            stopSession(e.getPlayer().getUniqueId());
            msg(e.getPlayer(), "Joget berhenti.");
        }
    }

    @EventHandler
    public void onConsume(PlayerItemConsumeEvent e) {
        mbg.onEat(e.getPlayer(), e.getItem().getType());
    }

    @EventHandler
    public void onStand(PlayerArmorStandManipulateEvent e) {
        if (e.getRightClicked().getScoreboardTags().contains(Npc.TAG)) e.setCancelled(true);
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e) {
        final String original = e.getMessage();
        String m = original;
        for (Map.Entry<String, String> en : emots.entrySet()) m = m.replace(":" + en.getKey() + ":", en.getValue());
        e.setMessage(m);
        final Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(this, new Runnable() {
            @Override
            public void run() { games.handleChat(p, original); }
        });
    }

    // ================================================================ poin & toko

    private void showTop(Player p) {
        msg(p, "&6Poin kamu: &e" + data.getInt(p.getUniqueId(), "points") + "&6. Peringkat poin:");
        List<Map.Entry<String, Integer>> t = data.top("points", 5);
        if (t.isEmpty()) p.sendMessage(color("&7Belum ada data."));
        int i = 1;
        for (Map.Entry<String, Integer> en : t) p.sendMessage(color("&e" + (i++) + ". &f" + en.getKey() + " &7- &a" + en.getValue()));
    }

    private void shop(Player p, String[] a) {
        List<String> list = getConfig().getStringList("shop");
        if (a.length == 0 || a[0].equalsIgnoreCase("list")) {
            msg(p, "&6Toko poin (poin kamu: &e" + data.getInt(p.getUniqueId(), "points") + "&6):");
            int i = 1;
            for (String s : list) {
                String[] x = s.split(":");
                if (x.length < 3) continue;
                p.sendMessage(color("&e" + (i++) + ". &f" + x[1] + "x " + x[0] + " &7- &a" + x[2] + " poin"));
            }
            p.sendMessage(color("&7Beli dengan /tukar <nomor>"));
            return;
        }
        int n;
        try { n = Integer.parseInt(a[0]); } catch (NumberFormatException ex) { msg(p, "&cPakai /tukar <nomor>"); return; }
        if (n < 1 || n > list.size()) { msg(p, "&cNomor tidak ada."); return; }
        String[] x = list.get(n - 1).split(":");
        try {
            Material m = Material.matchMaterial(x[0]);
            int amt = Integer.parseInt(x[1].trim());
            int cost = Integer.parseInt(x[2].trim());
            if (m == null) { msg(p, "&cItem tidak tersedia di versi ini."); return; }
            if (data.getInt(p.getUniqueId(), "points") < cost) { msg(p, "&cPoin tidak cukup."); return; }
            data.add(p.getUniqueId(), "points", -cost);
            for (ItemStack left : p.getInventory().addItem(new ItemStack(m, amt)).values())
                p.getWorld().dropItemNaturally(p.getLocation(), left);
            msg(p, "&aBerhasil menukar &e" + cost + " poin&a.");
        } catch (Exception ex) {
            msg(p, "&cEntri toko rusak.");
        }
    }

    private void massal(CommandSender by) {
        int dur = 30;
        for (Player o : Bukkit.getOnlinePlayers()) startDance(o, dur);
        Bukkit.broadcastMessage(color(getConfig().getString("prefix", "") + "&6&lJOGET MASSAL! &fSemua ikut goyang " + dur + " detik!"));
    }

    // ================================================================ commands

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("bowogendut.use")) { msg(s, "&cKamu tidak punya izin."); return true; }
        String name = c.getName().toLowerCase(Locale.ROOT);

        if (name.equals("bowogendut")) return cmdMain(s, a);

        if (!(s instanceof Player)) { msg(s, "Perintah ini untuk pemain."); return true; }
        Player p = (Player) s;

        if (name.equals("mbg")) return cmdMbg(p, a);
        if (name.equals("tebak")) return cmdTebak(p, a);
        if (name.equals("poin")) { showTop(p); return true; }
        if (name.equals("tukar")) { shop(p, a); return true; }
        if (name.equals("radio")) return cmdRadio(p, a);
        if (name.equals("emot")) return cmdEmot(p, a);
        return true;
    }

    private boolean cmdMain(CommandSender s, String[] a) {
        if (a.length > 0 && a[0].equalsIgnoreCase("reload")) {
            if (!s.hasPermission("bowogendut.admin")) { msg(s, "&cTidak ada izin."); return true; }
            reloadConfig();
            songs.load();
            mbg.reload();
            games.reload();
            loadEmots();
            msg(s, "Config, lagu, dan tebakan dimuat ulang.");
            return true;
        }
        if (!(s instanceof Player)) { msg(s, "Perintah ini untuk pemain."); return true; }
        Player p = (Player) s;
        if (a.length == 0) { toggle(p); return true; }
        String sub = a[0].toLowerCase(Locale.ROOT);

        if (sub.equals("gui") || sub.equals("menu")) { openGui(p); return true; }
        if (sub.equals("stop")) { stopSession(p.getUniqueId()); msg(p, "Joget berhenti."); return true; }
        if (sub.equals("finale")) { finale(p); return true; }

        if (sub.equals("style") || sub.equals("gaya")) {
            if (a.length < 2 || !STYLES.contains(a[1].toLowerCase(Locale.ROOT))) { msg(p, "Gaya: spin, hop, disco"); return true; }
            setStyle(p, a[1].toLowerCase(Locale.ROOT));
            return true;
        }

        if (sub.equals("song")) {
            if (a.length < 2 || a[1].equalsIgnoreCase("list")) {
                msg(p, "Lagu tersedia:");
                for (String id : songs.ids()) p.sendMessage(color("&7- &e" + id + " &7(" + songs.title(id) + ")"));
                return true;
            }
            String id = a[1].toLowerCase(Locale.ROOT);
            if (!songs.ids().contains(id)) { msg(p, "&cLagu tidak ditemukan. /bg song list"); return true; }
            setSong(p, id);
            return true;
        }

        if (sub.equals("massal")) {
            if (!p.hasPermission("bowogendut.admin")) { msg(p, "&cTidak ada izin."); return true; }
            massal(p);
            return true;
        }

        if (sub.equals("npc")) {
            if (!p.hasPermission("bowogendut.npc")) { msg(p, "&cTidak ada izin."); return true; }
            String act = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "";
            if (act.equals("spawn")) spawnNpc(p);
            else if (act.equals("remove")) removeNearest(p);
            else if (act.equals("removeall")) {
                for (Npc n : npcs) n.stop();
                npcs.clear();
                saveNpcs();
                msg(p, "Semua NPC dihapus.");
            } else msg(p, "Pakai: /bg npc <spawn|remove|removeall>");
            return true;
        }

        Player target = Bukkit.getPlayerExact(a[0]);
        if (target != null && p.hasPermission("bowogendut.admin")) {
            toggle(target);
            msg(p, target.getName() + " di-toggle joget.");
            return true;
        }
        msg(p, "Pakai: /bg [gui|stop|style|song|npc|massal|finale|reload]");
        return true;
    }

    private boolean cmdMbg(Player p, String[] a) {
        String sub = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "";
        if (sub.equals("claim")) mbg.claim(p);
        else if (sub.equals("harian")) mbg.daily(p);
        else if (sub.equals("makan")) mbg.windowClaim(p);
        else if (sub.equals("menu")) msg(p, "Menu MBG hari ini: &e" + mbg.menuToday());
        else if (sub.equals("donasi")) mbg.donate(p);
        else if (sub.equals("dapur")) mbg.dapurStatus(p);
        else if (sub.equals("gizi")) mbg.giziStatus(p);
        else if (sub.equals("top")) mbg.top(p);
        else if (sub.equals("jam") && p.hasPermission("bowogendut.admin")) mbg.startWindow();
        else {
            msg(p, "&6MBG &7- &f/mbg claim, harian, makan, menu, donasi, dapur, gizi, top");
            msg(p, "Menu hari ini: &e" + mbg.menuToday());
        }
        return true;
    }

    private boolean cmdTebak(Player p, String[] a) {
        if (!p.hasPermission("bowogendut.game")) { msg(p, "&cTidak ada izin."); return true; }
        String sub = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "";
        if (sub.equals("stop")) {
            if (p.hasPermission("bowogendut.admin")) games.stop(p); else msg(p, "&cTidak ada izin.");
            return true;
        }
        Games.Type t;
        if (sub.equals("tebak")) t = Games.Type.TEBAK;
        else if (sub.equals("kata")) t = Games.Type.KATA;
        else if (sub.equals("math")) t = Games.Type.MATEMATIKA;
        else if (sub.equals("angka")) t = Games.Type.ANGKA;
        else {
            Games.Type[] ts = Games.Type.values();
            t = ts[new java.util.Random().nextInt(ts.length)];
        }
        games.start(p, t);
        return true;
    }

    private boolean cmdRadio(Player p, String[] a) {
        String sub = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "";
        if (sub.equals("off")) { radioOff(p); msg(p, "Radio dimatikan."); return true; }
        if (!sub.isEmpty() && !sub.equals("on")) {
            if (!songs.ids().contains(sub)) { msg(p, "&cLagu tidak ada. /bg song list"); return true; }
            chosen.put(p.getUniqueId(), sub);
        }
        radioOn(p);
        msg(p, "Radio menyala: &e" + songs.title(songOf(p.getUniqueId())) + "&f. Matikan dengan /radio off.");
        return true;
    }

    private boolean cmdEmot(Player p, String[] a) {
        if (a.length == 0 || a[0].equalsIgnoreCase("list")) {
            msg(p, "Emot (ketik :nama: di chat atau /emot nama):");
            for (Map.Entry<String, String> en : emots.entrySet()) p.sendMessage(color("&e:" + en.getKey() + ": &f" + en.getValue()));
            return true;
        }
        String e = emots.get(a[0].toLowerCase(Locale.ROOT));
        if (e == null) { msg(p, "&cEmot tidak ada. /emot list"); return true; }
        Bukkit.broadcastMessage(color("&7" + p.getName() + ": &f" + e));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
        List<String> out = new ArrayList<String>();
        String name = c.getName().toLowerCase(Locale.ROOT);
        if (a.length == 1) {
            if (name.equals("bowogendut")) {
                out.addAll(Arrays.asList("gui", "stop", "style", "song", "finale"));
                if (s.hasPermission("bowogendut.npc")) out.add("npc");
                if (s.hasPermission("bowogendut.admin")) out.addAll(Arrays.asList("massal", "reload"));
            } else if (name.equals("mbg")) out.addAll(Arrays.asList("claim", "harian", "makan", "menu", "donasi", "dapur", "gizi", "top"));
            else if (name.equals("tebak")) out.addAll(Arrays.asList("tebak", "kata", "math", "angka", "stop"));
            else if (name.equals("radio")) { out.addAll(Arrays.asList("on", "off")); out.addAll(songs.ids()); }
            else if (name.equals("emot")) { out.add("list"); out.addAll(emots.keySet()); }
            else if (name.equals("tukar")) out.add("list");
        } else if (a.length == 2 && name.equals("bowogendut")) {
            if (a[0].equalsIgnoreCase("song")) { out.add("list"); out.addAll(songs.ids()); }
            else if (a[0].equalsIgnoreCase("style")) out.addAll(STYLES);
            else if (a[0].equalsIgnoreCase("npc")) out.addAll(Arrays.asList("spawn", "remove", "removeall"));
        }
        Iterator<String> it = out.iterator();
        String prefix = a[a.length - 1].toLowerCase(Locale.ROOT);
        while (it.hasNext()) if (!it.next().toLowerCase(Locale.ROOT).startsWith(prefix)) it.remove();
        return out;
    }
}
