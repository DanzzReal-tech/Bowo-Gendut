package id.bowogendut;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.AbstractMap;
import java.util.UUID;

/** Penyimpanan poin, skor gizi, streak, dan progres dapur umum (data.yml). */
public class Data {

    private final BowoGendut plugin;
    private final File file;
    private final YamlConfiguration y;
    private boolean dirty;

    public Data(BowoGendut plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
        this.y = YamlConfiguration.loadConfiguration(file);
    }

    private static String k(UUID id, String key) { return "players." + id + "." + key; }

    public int getInt(UUID id, String key) { return y.getInt(k(id, key), 0); }

    public long getLong(UUID id, String key, long def) { return y.getLong(k(id, key), def); }

    public void set(UUID id, String key, Object v) {
        y.set(k(id, key), v);
        dirty = true;
    }

    public int add(UUID id, String key, int delta) {
        int n = getInt(id, key) + delta;
        set(id, key, n);
        return n;
    }

    public void name(UUID id, String name) {
        if (!name.equals(y.getString(k(id, "name"), ""))) set(id, "name", name);
    }

    public int global(String key) { return y.getInt("global." + key, 0); }

    public void setGlobal(String key, int v) {
        y.set("global." + key, v);
        dirty = true;
    }

    public List<Map.Entry<String, Integer>> top(String key, int n) {
        List<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String, Integer>>();
        ConfigurationSection ps = y.getConfigurationSection("players");
        if (ps != null) {
            for (String id : ps.getKeys(false)) {
                int v = ps.getInt(id + "." + key, 0);
                if (v > 0) list.add(new AbstractMap.SimpleEntry<String, Integer>(ps.getString(id + ".name", "?"), v));
            }
        }
        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) {
                return b.getValue() - a.getValue();
            }
        });
        return list.size() > n ? list.subList(0, n) : list;
    }

    public void save() {
        if (!dirty) return;
        try {
            y.save(file);
            dirty = false;
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal simpan data.yml: " + e.getMessage());
        }
    }
}
